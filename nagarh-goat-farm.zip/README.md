# Nagarh Goat Farm House

This is a simple React project for an animal shelter website.

## How to run

1. Run `npm install`
2. Run `npm start` (if using Create React App)

---

Contact email: pathanwahid955@gmail.com
