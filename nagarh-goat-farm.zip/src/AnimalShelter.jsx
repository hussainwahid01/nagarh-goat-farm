import React from "react";

export default function AnimalShelter() {
  return (
    <div style={{ minHeight: "100vh", padding: "2rem", background: "linear-gradient(to bottom right, #d9f99d, #fef08a)" }}>
      <header style={{ textAlign: "center", marginBottom: "3rem" }}>
        <h1 style={{ fontSize: "3rem", color: "#166534" }}>Nagarh Goat Farm House</h1>
        <p style={{ fontSize: "1.25rem", color: "#4b5563" }}>Give them a home, gain a heart ❤️</p>
        <p style={{ color: "#374151" }}>Location: Jeipahari, JJN (Rajasthan)</p>
      </header>
      <section style={{ display: "flex", gap: "1rem", flexWrap: "wrap", justifyContent: "center" }}>
        {[1, 2, 3].map((_, i) => (
          <div key={i} style={{ width: "300px", boxShadow: "0 10px 15px rgba(0,0,0,0.1)", borderRadius: "1rem", overflow: "hidden", background: "white" }}>
            <img src={`https://place-puppy.com/300x20${i}`} alt="Animal" style={{ width: "100%", height: "240px", objectFit: "cover" }} />
            <div style={{ padding: "1rem" }}>
              <h2 style={{ fontSize: "1.5rem", color: "#166534" }}>Buddy</h2>
              <p style={{ color: "#4b5563" }}>2-year-old Labrador, friendly and playful.</p>
              <button style={{ marginTop: "1rem", width: "100%", padding: "0.75rem", backgroundColor: "#16a34a", color: "white", border: "none", borderRadius: "0.5rem", cursor: "pointer" }}>
                Adopt Now
              </button>
            </div>
          </div>
        ))}
      </section>
      <section style={{ marginTop: "4rem", textAlign: "center" }}>
        <h2 style={{ fontSize: "2rem", color: "#166534", marginBottom: "1rem" }}>How You Can Help</h2>
        <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "1rem", width: "250px", boxShadow: "0 10px 15px rgba(0,0,0,0.1)" }}>
            <h3>Adopt</h3>
            <p>Find your new best friend and give them a loving home.</p>
          </div>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "1rem", width: "250px", boxShadow: "0 10px 15px rgba(0,0,0,0.1)" }}>
            <h3>Volunteer</h3>
            <p>Join our team to help care for and socialize our animals.</p>
          </div>
          <div style={{ background: "white", padding: "1.5rem", borderRadius: "1rem", width: "250px", boxShadow: "0 10px 15px rgba(0,0,0,0.1)" }}>
            <h3>Contact Us</h3>
            <p>Reach out to donate or ask about available animals.</p>
            <p>Email: <a href="mailto:pathanwahid955@gmail.com" style={{ color: "#166534", textDecoration: "underline" }}>pathanwahid955@gmail.com</a></p>
            <button onClick={() => window.open("https://maps.app.goo.gl/QKNmAa8wN5b1sNqA9", "_blank")} style={{ marginTop: "1rem", backgroundColor: "#16a34a", color: "white", border: "none", padding: "0.75rem", borderRadius: "0.5rem", cursor: "pointer" }}>
              View on Google Maps
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
