export function Card({ children, className }) {
  return (
    <div className={className} style={{ boxShadow: "0 10px 15px rgba(0,0,0,0.1)", borderRadius: "1rem", background: "white" }}>
      {children}
    </div>
  );
}

export function CardContent({ children, className }) {
  return <div className={className} style={{ padding: "1rem" }}>{children}</div>;
}
