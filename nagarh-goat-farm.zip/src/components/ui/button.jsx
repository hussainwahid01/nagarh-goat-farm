export function Button({ children, className, onClick }) {
  return (
    <button className={className} style={{ padding: "0.75rem 1rem", backgroundColor: "#16a34a", color: "white", border: "none", borderRadius: "0.5rem", cursor: "pointer" }} onClick={onClick}>
      {children}
    </button>
  );
}
